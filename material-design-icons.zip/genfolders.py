l = ['action', 'alert', 'av', 'communication', 'content', 'device', 'editor', 'file', 'foldernames.py', 'hardware', 'home', 'image', 'maps', 'navigation', 'notification', 'places', 'social', 'toggle']

import os
for item in l:
    os.makedirs(item)